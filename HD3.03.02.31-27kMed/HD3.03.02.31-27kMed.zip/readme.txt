Release notes HD3.03.02.17A:
1) When you insert the SD card with script name "gpcal.txt" parser will kick in and be ready to apply changes. You will NOT see any changes to video quality immediately.
2) When you hit record button you will see the effect of your settings. You will see the effect only if you are in video mode.
3) When you stop recording the video and go to preview mode, most of the settings will be preserved as per the script except minimum gain and maximum gain for AE
4) After first record, If you go to still, burst or time lapse mode and come back to video preview mode you may loose some settings like manual exposure 
5) Most of the settings in the script are self explanatory but please read the comments written above the parameters in the script
6) In this release JPEG capture stores 3A debug info also
